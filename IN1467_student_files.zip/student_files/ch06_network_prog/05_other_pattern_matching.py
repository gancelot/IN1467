"""

    05_match_case.py
    The pattern matching feature of the match-case control...
    Example requires python 3.10+ to run.

"""
#
expressions = 'one', 1, (1, ), (1, 2, 3), [1, 2, 4], (1, 2, 4, 5, 3), 2

for expr in expressions:
    match expr:
        case 1 | 2:
            print('One or two')
        case [x]:
            print('Match on any single value in sequence: ', x)
        case [1, x, 3]:
            print('Match 1 at begin, any middle, 3 at end, ', x)
        case (1, x, y):
            print('Match 1 at begin, any middle and end,', x, y)
        case 1:
            print('One again')       # only one case will work
        case [1, *x, 3]:
            print('Match 1 at begin, multiple middle, 3 end, ', x)
        case _:
            print('Default condition (match anything).')