"""

    02_urllib.py - Using the urllib modules.

"""
from urllib.request import urlopen
from urllib.parse import urlparse

url1 = 'https://httpbin.org/html'
url2 = 'https://httpbin.org/encoding/utf8'

with urlopen(url1) as f:
    results = f.read().decode('utf-8')
    print(results)


# shortened version...(no close)
print(urlopen(url2).read().decode('utf-8'))


result = urlparse('https://docs.python.org/3/library/index.html')
print(result)
print(result.netloc)
