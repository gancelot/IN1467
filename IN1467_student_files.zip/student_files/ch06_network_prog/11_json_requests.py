"""

    11_json_requests.py
    Using .text and .json() is easy.

"""
import requests

r = requests.get('https://httpbin.org/json')
print(r.text)
print(r.json())
