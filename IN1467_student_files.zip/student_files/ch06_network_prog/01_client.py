import socket
import sys  

host = 'docs.python.org'
port = 80
path = '/'
request = bytes(f'GET {path} HTTP/1.1\r\nHost: {host}:{port}\r\n\r\n', encoding='utf-8')

print('Creating socket...')
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

try:
    ip_address = socket.gethostbyname(host)
except socket.gaierror:
    print('Error resolving {host}')
    sys.exit()

print(f'Connecting to {host} ({ip_address}).')
try:
    s.connect((ip_address, port))
except socket.error as err:
    print('Error connecting to host: {err}')
    sys.exit()

try:
    s.sendall(request)
except socket.error as err:
    print('Error sending request: {err}')
    sys.exit()

print('Receiving data.')
resp = s.recv(4096)
print('Closing socket connection.')
s.close()
print('Server response: ')
print(resp)
