"""

    08_soup.py
    Parsing HTML with BeautifulSoup.

"""
import sys

from bs4 import BeautifulSoup
import requests

import urllib3
print(urllib3.__version__, requests.__version__, sys.version_info)

page = requests.get('https://www.python.org').text
soup = BeautifulSoup(page, 'html.parser')

print(soup.title)
all_h2 = soup.find_all('h2')
print(len(all_h2))
print([elem.text for elem in all_h2])
