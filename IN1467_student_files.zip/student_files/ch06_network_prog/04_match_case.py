"""

    04_match_case.py
    Illustrates the use and variations of the match-case control.
    Example requires python 3.10+ to run.

"""
import sys

from urllib.request import urlopen
from urllib.error import URLError, HTTPError

results = ''

url500 = 'https://httpbin.org/status/500'
url404 = 'https://httpbin.org/foo'
url403 = 'https://httpbin.org/status/403'


for url in url500, url404, url403:
    try:
        with urlopen(url) as f:
            results = f.read().decode('utf-8')
            print(results)
    except HTTPError as err:
            match err.code:
                case 404:
                    print('Page not found.  Bad URL.', file=sys.stderr)
                case 403:
                    print('Access denied.', file=sys.stderr)
                case _:
                    print('An HTTP error occurred.', file=sys.stderr)
    except URLError as err:
        print(f'Error: {err}', file=sys.stderr)

