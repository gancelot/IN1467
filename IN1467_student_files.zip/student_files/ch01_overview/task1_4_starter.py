"""

      task1_4_starter.py   -   File size sorter utility

      This script will prompt for a path (and/or) pattern to search.  It should
      display a list of files matching that path in order of largest to smallest

"""
import glob
import os
dir_contents = []

path = '.'
match = '*'
for pathitem in glob.glob('/'.join([path, match])):             # Lists ./*
    dir_contents.append(pathitem)

print(dir_contents)

files = []

# put your solution here
# Step 1. Iterate over the directory contents, test to see if they are files
#         Hint: use os.path.isfile(filename)

# Step 2. If the item is a file, save the filename (not the path) in the files list along with the file size
#         Hint: use files.append((os.path.basename(item), os.path.getsize(item)))

# Step 3. Sort the list according to file size.
#         Hint: use list.sort() or sorted() along with a key.
#               The key function should return the second item in the tuple, the file size.  Sort largest to smallest.

# Step 4. Display the final sorted files.