"""

    10_sets.py
    Use of the set type.

"""
s1 = set([1, 2, 3, 2])
print(len(s1))			        # 3

s2 = {4, 5, 6}
print(s1.isdisjoint(s2))        # True (no elements in each set are in common)

s3 = frozenset([2, 4, 7])       # an immutable set
print(s2.difference(s3))        # {5, 6}    (5 & 6 do not appear in s3)

records = set()
records.add(('John',  'Smith',   43, 'jsbrony@yahoo.com'))
records.add(('Ellen', 'James',   32, 'jamestel@google.com'))
records.add(('Sally', 'Edwards', 36, 'steclone@yahoo.com'))
records.add(('Ellen', 'James',   32, 'jamestel@google.com'))        # this one is not added since it is a duplicate
print(len(records))                                                 # 3
for record in records:
    print(record)
