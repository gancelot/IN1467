"""

       Mini-task 3  - Finding their age, given their name...

       Given the search_name below, can you find the person's age in the records?
       Hints:
       - Use split() to split the search_name as follows:
           first, last = 'John Smith'.split()


"""
records = [
    ('John',  'Smith',   43, 'jsbrony@yahoo.com'),
    ('Ellen', 'James',   32, 'jamestel@google.com'),
    ('Sally', 'Edwards', 36, 'steclone@yahoo.com'),
    ('Keith', 'Cramer',  29, 'kcramer@sinotech.com')
]

search_name = 'Ellen James '






# Advanced:
# Change the search_name above to something like the following:

# search_name = 'Richard Barnes'

# Can you modify your solution above to display a message when the name is not found.

# Hint: use the rare else-block feature of the for-loop,
#       breaking out of the for-loop causes the else of the for-loop to not be executed.
