"""

       Mini-task 3 Solution - Finding their age, given their name...

"""
records = [
    ('John',  'Smith',   43, 'jsbrony@yahoo.com'),
    ('Ellen', 'James',   32, 'jamestel@google.com'),
    ('Sally', 'Edwards', 36, 'steclone@yahoo.com'),
    ('Keith', 'Cramer',  29, 'kcramer@sinotech.com')
]

search_name = 'Ellen James '

search_first, search_last = search_name.split()
for first, last, age, email in records:
    if first.lower() == search_first.lower() and last.lower() == search_last.lower():
        print(f'{search_name}\'s age: {age}.')


# Using the rare feature of the for-loop,
# can you have it display a message when the name is not found.
search_name = 'Richard Barnes'

search_first, search_last = search_name.split()
for first, last, age, email in records:
    if first.lower() == search_first.lower() and last.lower() == search_last.lower():
        print(f'{search_name}\'s age: {age}.')
        break
else:
    print(f'{search_name} did not exist.')