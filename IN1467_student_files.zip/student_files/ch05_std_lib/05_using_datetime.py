"""

    05_using_datetime.py
    Working with date, datetime objects.

"""

from datetime import date, datetime


now1 = datetime.now()      # current date & time
now2 = date.today()        # current date
print(now1, now2)

d1 = date(2023, 11, 17)
print(d1.year, d1.month, d1.day)

print(d1.strftime('%d-%b-%Y'))

d2 = date(2023, 11, 27)
print(f'{d2:%Y%m%d}')

print(d2 - d1)
