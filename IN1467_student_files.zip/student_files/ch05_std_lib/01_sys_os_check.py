import atexit
import sys


def cleanup():
    with open('sys_params.txt', 'w', encoding='utf-8') as f:
        print(f'OS: {sys.platform}', file=f)
        print(f'Interpreter location: {sys.executable}', file=f)
        print(f'Module locations: {sys.path}', file=f)


atexit.register(cleanup)


if sys.platform == "win32":
    print('Running Windows...')
    sys.exit()
elif sys.platform == "darwin":
    print('Running OS X')
elif sys.platform == "linux" or sys.platform == "linux2":
    print('Running Linux')
    sys.exit()


