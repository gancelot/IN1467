"""

    02_ctxmgr01.py
    Before and after using the 'with' control

"""
import sys

lines = []
f = None
try:
    f = open('alice.txt', encoding='utf-8-sig')
    lines = f.readlines()
except IOError as err:
    print(f'Handled {err}', file=sys.stderr)
finally:
    if f:
        f.close()

print(f'{len(lines)} lines read.')


lines = []
try:
    with open('alice.txt', encoding='utf-8-sig') as f:
        lines = f.readlines()
except IOError as err:
    print(f'Handled {err}', file=sys.stderr)

print(f'{len(lines)} lines read.')
