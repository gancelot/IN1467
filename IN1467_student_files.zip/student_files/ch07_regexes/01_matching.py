"""

    01_matching.py
    Illustrating the difference between re.match() and re.search().

"""
from pathlib import Path
import re

# speech refers to gettysburg address, "Four score and seven years ago, ..."
speech = Path('../resources/gettysburg.txt').open(encoding='utf-8').read()
print(re.match('seven', speech))
print(re.search('seven', speech))
print(re.match('four', speech))
print(re.search('four', speech))
print(re.match('Four', speech))
print(re.search('Four', speech))


matchobj = re.search('seven', speech)
print(type(matchobj))
if matchobj:
    print(f'seven found at position: {matchobj.start()}')



matchobj = re.search(r'(\w+) (\w+) (\w+)', 'Four score and seven years ago')
print(matchobj.groups())                # ('Four', 'score', 'and')
print(matchobj.group(0))                # Four score and
print(matchobj.group(1))                # Four
print(matchobj.group(2))                # score
print(matchobj.group(3))                # and

str_matches = re.findall(r'\w+', 'Four score and seven years ago')
print(f'How many words: {len(str_matches)}')
print(str_matches)
